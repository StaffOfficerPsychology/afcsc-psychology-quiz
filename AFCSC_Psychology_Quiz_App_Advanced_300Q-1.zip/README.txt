AFCSC SENIOR COURSE 48 – ADVANCED AUTO-MARKING QUIZ APP
=======================================================

This package contains the advanced automatic-marking version of the
300-question, 12-module psychology and staff effectiveness quiz.

ASSESSMENT METHOD
- 12 modules, 25 questions per module.
- Each question is scored automatically from 0 to 2.
- The engine checks rubric-linked concept indicators rather than relying
  on exact wording.
- It recognises configured alternative expressions and equivalent
  professional/military terminology (for example, synchronise/deconflict/
  coordinate; materiel/equipment/stores; situational awareness/
  situational understanding).
- Partial concept coverage earns partial credit.
- It checks for explanatory/linking expressions where the source rubric
  or model answer indicates a relationship, purpose, effect or dependency.
- Feedback identifies criteria substantially covered, partially covered,
  or not sufficiently demonstrated, plus detected concepts.
- Model answers remain visible for learning and revision.

SCORING
- 2 marks per question.
- 50 marks per module.
- 600 marks across all 12 modules.
- Module and cumulative scores are saved locally.
- Export creates a JSON score report.

IMPORTANT LIMITATIONS
This is a deterministic, rubric-based assessment engine. It is more
flexible than exact keyword matching, but it is not a generative AI model
and does not fully understand meaning as a trained human examiner does.
It may miss valid novel expressions, misunderstand negation or context,
or award credit when terms appear without a sound explanation. Its
relationship check looks for explanatory/linking language and adequate
concept coverage; it does not prove deep causal reasoning. Use the
feedback and model answer to guide learning. A human examiner remains
the authority for formal grading. The vocabulary and rubric indicators
can be refined further using instructor-approved accepted answers.

ANDROID APK BUILD
1. Install Android Studio with a compatible Android SDK.
2. Extract this ZIP.
3. Open the "android" folder in Android Studio.
4. Allow Gradle sync to complete.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK output location.

This is an Android Studio project, not a precompiled APK.

PWA INSTALLATION
The "www" folder is a Progressive Web App. Host it on an HTTPS web server,
open the hosted address in Chrome on Android, then choose Install app /
Add to Home screen. Open once online so the app can cache for offline use.

PRIVACY
Scores and answers are stored locally on the device. They are not
automatically synchronised between devices or sent to a server.
