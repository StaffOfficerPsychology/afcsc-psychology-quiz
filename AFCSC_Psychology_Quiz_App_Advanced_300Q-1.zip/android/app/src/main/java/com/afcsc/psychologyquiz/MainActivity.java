package com.afcsc.psychologyquiz;
import android.app.Activity;import android.os.Bundle;import android.webkit.WebView;import android.webkit.WebSettings;
public class MainActivity extends Activity { @Override public void onCreate(Bundle b){super.onCreate(b);WebView w=new WebView(this);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setWebViewClient(new android.webkit.WebViewClient());setContentView(w);w.loadUrl("file:///android_asset/index.html");} @Override public void onBackPressed(){super.onBackPressed();}}
